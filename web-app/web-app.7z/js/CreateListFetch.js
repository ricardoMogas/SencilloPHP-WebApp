class CreateListFetch {
    constructor(url, targetElementId) {
        this.url = url;
        this.targetElementId = targetElementId;
    }

    fetchData() {
        fetch(this.url)
            .then(res => res.json())
            .then(data => {
                const response = data.result;
                const lista = document.getElementById(this.targetElementId);
                response.forEach(element => {
                    const li = document.createElement('li');
                    li.innerHTML = element.name;
                    lista.appendChild(li);
                });
            });
    }
}


